build=build/Release

~/Library/Python/*/bin/macpack build/Release/canvas.node -d .

